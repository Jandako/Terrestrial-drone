package com.example.pc_x.tankatron;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;

import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.ColorRes;
import android.support.constraint.ConstraintLayout;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;

import io.github.controlwear.virtual.joystick.android.JoystickView;

public class MainActivity extends AppCompatActivity {

    public TcpClient tcpMovementClient;
    public TcpClient tcpSensorClient;
    public TcpClient tcpImageStreamerClient;

  /*  public com.example.pc_x.tankatron.MovementTCP tcpM;
    public com.example.pc_x.tankatron.SensorTCP tcpS;
    public com.example.pc_x.tankatron.ImageStreamerTCP tcpStr;
    public SeekBarListener seekbar1;
    public SeekBarListener seekbar2;
    public SeekBarListener seekbar3;
    public SeekBarListener seekbar4;*/


    public static int threadNumberControlSensor = 0;

    public String ipAddress = "192.168.12.1";
    public int controlSCKPort = 12345;
    public int sensorSCKPort = 12356;
    public int imageStreameSCKPort = 12365;

    public Timer timer;
    public Timer timerImage;

    public String arm_positions_file = "arm_positions.txt";

    int motorIzquierda = -1;
    int motorDerecha = -1;
    int direccionMotorI = 0;
    int direccionMotorD = 0;

    int progress1 = 0;
    int progress2 = 0;
    int progress3 = 0;
    int progress4 = 0;

    int pinPinza = 6;
    int pinCodo = 2;
    int pinHombro = 19;
    int pinBase = 26;

    public static String trackingResponse = "-1";
    public static boolean trackingState = false;

    ConstraintLayout layoutContent;

    WebView navStreamer;
    SeekBar anguloPinza;
    SeekBar anguloCodo;
    SeekBar anguloHombro;
    SeekBar anguloBase;
    TextView txtPinza;
    TextView txtCodo;
    TextView txtHombro;
    TextView txtBase;

    Button pos1;
    Button pos2;
    Button pos3;
    Button pos4;
    Button pos5;
    Button pos6;
    Button pos7;
    Button pos8;
    Button pos9;

    ImageView img1; //= findViewById(R.id.img1);
    ImageView img2; //= findViewById(R.id.img2);
    int imgShowed = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void close(View v) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                tcpMovementClient.sendString("C#");
            }
        });
        th.start();
    }

    public void startControlSocket(View v) {
        //--Iniciamos el hilo asincrono que conecta el socket
        MovementTCP movementTcpConnection = new MovementTCP();
        SensorTCP sensorTcpConnection = new SensorTCP();

        img1 = findViewById(R.id.imageView1);
        img2 = findViewById(R.id.imageView2);
        ImageStreamerTCP imageStreamerTcpConnection = new ImageStreamerTCP();

        movementTcpConnection.execute();
        sensorTcpConnection.execute();
        imageStreamerTcpConnection.execute();

        setContentView(R.layout.activity_control);
        navStreamer = findViewById(R.id.navStreamer);
        navStreamer.loadUrl("http://192.168.12.1:8081");

        //--Crea el joystick y añade el evento
        JoystickView joystick = (JoystickView) findViewById(R.id.joystickView_right);
        joystick.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {
                sendJoyStickPosition(angle, strength);
            }
        });
        startLayoutManual();
    }

    public void launchRingDialog(View view) {
        final ProgressDialog ringProgressDialog = ProgressDialog.show(MainActivity.this, "Object tracking", "Activando seguimiento de objetos...", true);
        ringProgressDialog.setCancelable(false);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (trackingResponse.equals("-1")) {
                        Thread.sleep(300);
                    }
                } catch (Exception e) {

                }
                if (trackingResponse.equals("0")) {
                    Button buttonTrackingControl = findViewById(R.id.buttonTrackingControl);
                    buttonTrackingControl.setBackgroundResource(R.drawable.button_round_on);
                    buttonTrackingControl.setText("ACTIVAR");
                }

                ringProgressDialog.dismiss();
                trackingResponse = "-1";
            }
        }).start();
    }

    public void startLayouPosiciones() {

        if (trackingState) {
            Thread thread = new Thread(new RunnableTracking(tcpMovementClient, false));
            thread.start();
            trackingState = false;
        }

        View.OnClickListener shortClicker = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                posButtonPressed(v);
            }
        };
        View.OnLongClickListener longClicker = new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                boolean rtn = posButtonLongPressed(v);
                if (rtn) {
                    v.setBackgroundResource(R.drawable.button_save_position);

                }
                return rtn;

            }
        };

        pos1 = findViewById(R.id.pos_1);
        pos2 = findViewById(R.id.pos_2);
        pos3 = findViewById(R.id.pos_3);
        pos4 = findViewById(R.id.pos_4);
        pos5 = findViewById(R.id.pos_5);
        pos6 = findViewById(R.id.pos_6);
        pos7 = findViewById(R.id.pos_7);
        pos8 = findViewById(R.id.pos_8);
        pos9 = findViewById(R.id.pos_9);


        pos1.setOnClickListener(shortClicker);
        pos1.setOnLongClickListener(longClicker);

        pos2.setOnClickListener(shortClicker);
        pos2.setOnLongClickListener(longClicker);

        pos3.setOnClickListener(shortClicker);
        pos3.setOnLongClickListener(longClicker);

        pos4.setOnClickListener(shortClicker);
        pos4.setOnLongClickListener(longClicker);

        pos5.setOnClickListener(shortClicker);
        pos5.setOnLongClickListener(longClicker);

        pos6.setOnClickListener(shortClicker);
        pos6.setOnLongClickListener(longClicker);

        pos7.setOnClickListener(shortClicker);
        pos7.setOnLongClickListener(longClicker);

        pos8.setOnClickListener(shortClicker);
        pos8.setOnLongClickListener(longClicker);

        pos9.setOnClickListener(shortClicker);
        pos9.setOnLongClickListener(longClicker);
    }

    public void startLayoutManual() {

        if (trackingState) {
            Thread thread = new Thread(new RunnableTracking(tcpMovementClient, false));
            thread.start();
            trackingState = false;
        }

        anguloPinza = findViewById(R.id.anguloPinza2);
        anguloCodo = findViewById(R.id.anguloCodo2);
        anguloHombro = findViewById(R.id.anguloHombro2);
        anguloBase = findViewById(R.id.anguloBase2);

        txtPinza = findViewById(R.id.txtPinza2);
        txtCodo = findViewById(R.id.txtCodo2);
        txtHombro = findViewById(R.id.txtHombro2);
        txtBase = findViewById(R.id.txtBase2);

        anguloPinza.setMax(100);
        anguloCodo.setMax(100);
        anguloHombro.setMax(100);
        anguloBase.setMax(100);

        anguloPinza.getThumb().setColorFilter(Color.parseColor("#E6B530"), PorterDuff.Mode.SRC_IN);
        anguloCodo.getThumb().setColorFilter(Color.parseColor("#E6B530"), PorterDuff.Mode.SRC_IN);
        anguloHombro.getThumb().setColorFilter(Color.parseColor("#E6B530"), PorterDuff.Mode.SRC_IN);
        anguloBase.getThumb().setColorFilter(Color.parseColor("#E6B530"), PorterDuff.Mode.SRC_IN);

        anguloPinza.setOnSeekBarChangeListener(new SeekBarListener(1, txtPinza, "Pinza:", pinPinza));
        anguloCodo.setOnSeekBarChangeListener(new SeekBarListener(2, txtCodo, "Codo:", pinCodo));
        anguloHombro.setOnSeekBarChangeListener(new SeekBarListener(3, txtHombro, "Hombro:", pinHombro));
        anguloBase.setOnSeekBarChangeListener(new SeekBarListener(4, txtBase, "Base:", pinBase));

        anguloPinza.setProgress(progress1);
        anguloCodo.setProgress(progress2);
        anguloHombro.setProgress(progress3);
        anguloBase.setProgress(progress4);

        txtPinza.setText("Pinza: " + progress1 + "%");
        txtCodo.setText("Codo: " + progress2 + "%");
        txtHombro.setText("Hombro: " + progress3 + "%");
        txtBase.setText("Base: " + progress4 + "%");

    }

    public void startLayoutTracking() {
        //--
    }

    private int oldTabBarViewId = R.id.botonBrazo;

    public void changeFragment(View v) {

        if (oldTabBarViewId != v.getId()) {
            oldPosButtonViewId = -1;
            findViewById(oldTabBarViewId).setBackgroundResource(R.drawable.tab_bar_background);
            v.setBackgroundResource(R.drawable.tab_bar_pressed);

            layoutContent = findViewById(R.id.constraintLayout);
            layoutContent.removeAllViews();
            LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
            View childLayout;

            switch (v.getId()) {
                case R.id.botonBrazo:
                    childLayout = inflater.inflate(R.layout.brazo_manual, (ViewGroup) findViewById(R.id.layoutManual));
                    layoutContent.addView(childLayout);
                    startLayoutManual();
                    break;
                case R.id.botonPosiciones:
                    childLayout = inflater.inflate(R.layout.brazo_posiciones, (ViewGroup) findViewById(R.id.layoutPosiciones));
                    layoutContent.addView(childLayout);
                    startLayouPosiciones();
                    break;
                case R.id.botonSeguimiento:
                    childLayout = inflater.inflate(R.layout.brazo_tracking, (ViewGroup) findViewById(R.id.layoutTracking));
                    layoutContent.addView(childLayout);
                    startLayoutTracking();
                    break;
                default:
                    break;
            }

        }
        oldTabBarViewId = v.getId();
    }

    private int oldPosButtonViewId = -1;

    public void posButtonPressed(View v) {

        if (oldPosButtonViewId != v.getId()) {
            if (oldPosButtonViewId != -1) {
                findViewById(oldPosButtonViewId).setBackgroundResource(R.drawable.pos_button);
            }
            v.setBackgroundResource(R.drawable.pos_button_pressed);
            String fileContent = FileManager.readFile(arm_positions_file, getApplicationContext());
            Log.d("Read Go Position", "Content = " + fileContent);

            if (!fileContent.equals("#Error") && !fileContent.equals("#NotExist")) {
                ArrayList<String> arrPositions = FileManager.fileContentToArrayList(fileContent);

                String idView = v.getId() + "";

                for (int i = 0; i < arrPositions.size(); i++) {
                    String linea = arrPositions.get(i);
                    StringTokenizer tokenizer = new StringTokenizer(linea, ",");
                    String idButton = tokenizer.nextToken();

                    Log.d("Comparacion ID", "ID vista = " + idView + "      ID boton = " + idButton);

                    if (idView.equals(idButton)) {
                        final int pos1 = Integer.parseInt(tokenizer.nextToken());
                        final int pos2 = Integer.parseInt(tokenizer.nextToken());
                        final int pos3 = Integer.parseInt(tokenizer.nextToken());
                        final int pos4 = Integer.parseInt(tokenizer.nextToken());

                        sendArmPosition(pinCodo, pos2);
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                sendArmPosition(pinHombro, pos3);
                            }
                        }, 100);
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                sendArmPosition(pinBase, pos4);

                            }
                        }, 100);
                        //sendArmPosition(pinPinza, pos1);

                        //sendArmPosition(pinBase, pos4);

                        break;
                    }
                }
            }
        }

        //--Ir a posicion

        oldPosButtonViewId = v.getId();
    }

    public void borrarFichero(View v) {
        FileManager.writeFile(arm_positions_file, "", getApplicationContext());
    }

    public boolean posButtonLongPressed(View v) {
        boolean rtnr = false;
        String idView = v.getId() + "";
        String newPosition = v.getId() + "," + progress1 + "," + progress2 + "," + progress3 + "," + progress4;
        String fileContent = FileManager.readFile(arm_positions_file, getApplicationContext());

        Log.d("Creacion Fichero", "Contenido = " + fileContent);

        if (fileContent.equals("#NotExist")) {
            rtnr = FileManager.writeFile(arm_positions_file, newPosition, getApplicationContext());
        } else if (!fileContent.equals("#Error")) {
            ArrayList<String> arrListPositions = new ArrayList<String>();
            arrListPositions = FileManager.fileContentToArrayList(fileContent);

            String newFileContent = "";
            for (int i = 0; i < arrListPositions.size(); i++) {
                String linea = arrListPositions.get(i);
                StringTokenizer tokenizer = new StringTokenizer(linea, ",");
                String idButton = tokenizer.nextToken();


                if (!idView.equals(idButton)) {
                    newFileContent += linea + "%";
                }
            }
            newFileContent += newPosition;
            rtnr = FileManager.writeFile(arm_positions_file, newFileContent, getApplicationContext());
        }
        return rtnr;
    }

    public void sendJoyStickPosition(int angulo, int fuerza) {
        final int anguloF = angulo;
        final int fuerzaF = fuerza;
        int mI = fuerzaF;
        int mD = fuerzaF;
        int direccionI = 0;
        int direccionD = 0;
        //double mult = fuerzaF;

        if (anguloF >= 337 || anguloF >= 0 && anguloF <= 22)//giro derecha
        {
            direccionI = 1;
            direccionD = -1;
            //mI = 100;
            //mD = 100;
        } else if (anguloF >= 23 && anguloF <= 67)//medio giro derecha
        {
            direccionI = 1;
            direccionD = 0;
            //mI = 100;
            mD = 0;
        } else if (anguloF >= 68 && anguloF <= 113)//recto
        {
            direccionI = 1;
            direccionD = 1;
            //mI = 100;
            //mD = 100;
        } else if (anguloF >= 114 && anguloF <= 156)//medio giro izquierda
        {
            direccionI = 0;
            direccionD = 1;
            mI = 0;
            //mD = 100;
        } else if (anguloF >= 157 && anguloF <= 203)//giro izquierda
        {
            direccionI = -1;
            direccionD = 1;
            //mI = 100;
            //mD = 100;
        } else if (anguloF >= 204 && anguloF <= 246)//giro izquierda atras
        {
            direccionI = 0;
            direccionD = -1;
            mI = 0;
            // mD = 100;
        } else if (anguloF >= 247 && anguloF <= 293)//atras
        {
            direccionI = -1;
            direccionD = -1;
            //mI = 100;
            //mD = 100;
        } else if (anguloF >= 294 && anguloF <= 336)//giro derecha atras
        {
            direccionI = -1;
            direccionD = 0;
            //mI = 100;
            mD = 0;
        }
        /*mult = mult / 100;
        mI = (int) (mI * mult);
        mD = (int) (mD * mult);*/

        if (mI > 100 || mI == 99) {
            mI = 100;
        }
        if (mD > 100 || mD == 99) {
            mD = 100;
        }

        if (motorIzquierda != mI || motorDerecha != mD || direccionMotorI != direccionI || direccionMotorD != direccionD) {
            RunnableJoystick runnableJoystick = new RunnableJoystick(direccionI, direccionD, mI, mD);
            Thread threadJoystick = new Thread(runnableJoystick);
            threadJoystick.start();
        }

        motorIzquierda = mI;
        motorDerecha = mD;
        direccionMotorI = direccionI;
        direccionMotorD = direccionD;
    }

    public void sendArmPosition(int motor, int position) {
        RunnableBrazo rnb = new RunnableBrazo(motor, position);
        Thread thread = new Thread(rnb);
        thread.start();
    }

    public void resetSocket(View v) {


        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                tcpMovementClient.sendString("C#");
            }
        });
        thread.start();

        this.finish();
        System.exit(0);

        //tcpMovementClient.TCPClientClose();
        //tcpSensorClient.TCPClientClose();
        //tcpImageStreamerClient.TCPClientClose();

        //MovementTCP movementTcpConnection = new MovementTCP();
        //SensorTCP sensorTcpConnection = new SensorTCP();
        //ImageStreamerTCP imageStreamerTcpConnection = new ImageStreamerTCP();

        //movementTcpConnection.execute();
        //sensorTcpConnection.execute();
    }

    public void SwitchOff(View v)
    {
        //
    }

    public void trackingControl(View v) {
        trackingState = !trackingState;
        Thread thread = new Thread(new RunnableTracking(tcpMovementClient, trackingState));
        thread.start();
        if (trackingState) {
            launchRingDialog(v);
        }
        Button buttonTrackingControl = findViewById(R.id.buttonTrackingControl);
        if (!trackingState) {
            buttonTrackingControl.setBackgroundResource(R.drawable.button_round_on);
            buttonTrackingControl.setText("ACTIVAR");
        } else {
            buttonTrackingControl.setBackgroundResource(R.drawable.button_round_off);
            buttonTrackingControl.setText("DESACTIVAR");
        }


    }

    public void startTimer() {
        if (threadNumberControlSensor == 0) {
            timer = new Timer();
            TimerTask timerTask = new TimerTask() {

                @Override
                public void run() {

                    tcpSensorClient.sendString("SENSOR_REQUEST#");
                    String resp = tcpSensorClient.readString();
                    Log.d("Timer recibe: ", resp);
                    Log.d("Nº hilo: ", threadNumberControlSensor + "");

                    if (!resp.equals("EMPTY")) {

                        // Controla que solo exista una peticion simultanea
                        threadNumberControlSensor = 1;

                        StringTokenizer tokenizer = new StringTokenizer(resp, "#");

                        if (tokenizer.countTokens() >= 3) {
                            String sensor_1 = tokenizer.nextToken();
                            String sensor_2 = tokenizer.nextToken();
                            String sensor_3 = tokenizer.nextToken();

                            DecimalFormat df = new DecimalFormat("#.##");

                            final String sensor_d1 = sensor_1;
                            final String sensor_d2 = sensor_2;
                            final String sensor_d3 = sensor_3;

                            final int mq135 = Integer.parseInt(sensor_1);

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    TextView txt1 = findViewById(R.id.textViewMq135);
                                    TextView txt2 = findViewById(R.id.txt2);
                                    TextView txt3 = findViewById(R.id.txt3);

                                    String mq135Str = "Correcto";

                                    if (mq135 == 0) {
                                        mq135Str = "¡ALERTA!";
                                        txt1.setTextColor(Color.RED);
                                    } else {
                                        txt1.setTextColor(Color.GREEN);
                                    }
                                    txt1.setText(mq135Str);


                                    if (!sensor_d2.toLowerCase().equals("none")) {
                                        txt2.setText(sensor_d2 + "ºC");
                                    }

                                    if (!sensor_d3.toLowerCase().equals("none")) {
                                        txt3.setText(sensor_d3 + "%");
                                    }
                                }
                            });


                        }
                        threadNumberControlSensor = 0;
                    }
                }
            };
            timer.scheduleAtFixedRate(timerTask, 0, 2000);
        }
    }

    public void startTimerImageStreamer() {
        timerImage = new Timer();

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                img1 = findViewById(R.id.imageView1);
                img2 = findViewById(R.id.imageView2);
                tcpImageStreamerClient.sendString("NEXT#");
                final String resp = tcpImageStreamerClient.readBase64String();

                if (resp != "null" && !resp.equals("null")) {

                    // img1.setImageBitmap(bmp);

                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            try {
                                byte[] decodedString = Base64.decode(resp, Base64.DEFAULT);
                                Bitmap bmp = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                if (imgShowed == 1) {
                                    imgShowed = 2;
                                    img2.setImageBitmap(bmp);
                                    img2.setVisibility(View.VISIBLE);
                                    img1.setVisibility(View.INVISIBLE);
                                } else {
                                    imgShowed = 1;
                                    img1.setImageBitmap(bmp);
                                    img1.setVisibility(View.VISIBLE);
                                    img2.setVisibility(View.INVISIBLE);
                                }
                            } catch (Exception e) {
                                Log.d("Exception conversion img", e.getMessage());
                            }

                        }
                    });
                } else {
                    try {
                        img1.setVisibility(View.INVISIBLE);
                        img2.setVisibility(View.INVISIBLE);
                    }
                    catch(Exception e)
                    {
                        Log.d("Petamiento", "-------------------------------------");
                    }
                }

            }
        };
        timerImage.scheduleAtFixedRate(timerTask, 0, 100);
    }


    //
    public class RunnableJoystick implements Runnable {

        public int mIzq;
        public int mDer;
        public int direccionIzq, direccionDer;

        public RunnableJoystick(int direccionIzq, int direccionDer, int mIzq, int mDer) {
            super();
            this.mIzq = mIzq;
            this.mDer = mDer;
            if (mIzq == 0) {
                this.direccionIzq = 0;
            } else {
                this.direccionIzq = direccionIzq;
            }

            if (mDer == 0) {
                this.direccionDer = 0;

            } else {
                this.direccionDer = direccionDer;
            }
        }

        @Override
        public void run() {
            tcpMovementClient.sendString("M#" + direccionIzq + "#" + direccionDer + "#" + mIzq + "#" + mDer + "#");
        }
    }

    public class RunnableBrazo implements Runnable {

        public int motor;
        public int power;
        public double pwm;

        public RunnableBrazo(int motor, int power) {
            super();
            this.motor = motor;
            this.power = power;
            pwm = (power / 10) + 2.5;
        }

        @Override
        public void run() {
            Log.d("BRAZO", "M = " + motor + "   PWM = " + pwm);
            tcpMovementClient.sendString("B#" + motor + "#" + pwm + "#");
        }
    }


    //
    private class SeekBarListener implements SeekBar.OnSeekBarChangeListener {
        TextView txt;
        String texto;
        int motor;
        int id;
        int progress;

        public SeekBarListener(int id, TextView txt, String texto, int motor) {
            this.txt = txt;
            this.texto = texto;
            this.motor = motor;
            this.id = id;
        }

        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            if (fromUser) {
                seekBar.getThumb().setColorFilter(Color.parseColor("#F08F2E"), PorterDuff.Mode.SRC_IN);
                progress = (progress / 10) * 10;
                seekBar.setProgress(progress);
                this.progress = progress;
                txt.setText(texto + ": " + progress + "%");
            }
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {

            switch (id) {
                case 1:
                    progress1 = progress;
                    break;
                case 2:
                    progress2 = progress;
                    break;
                case 3:
                    progress3 = progress;
                    break;
                case 4:
                    progress4 = progress;
                    break;
            }
            seekBar.getThumb().setColorFilter(Color.parseColor("#E6B530"), PorterDuff.Mode.SRC_IN);

            sendArmPosition(motor, seekBar.getProgress());

        }

    }


    //
    public class MovementTCP extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
        }

        @Override
        protected Void doInBackground(Void... arg) {
            try {
                tcpMovementClient = new TcpClient(ipAddress, controlSCKPort);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void a) {
        }
    }

    public class SensorTCP extends AsyncTask<Void, Void, Void> {

        public boolean correct;

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected Void doInBackground(Void... arg) {
            try {
                tcpSensorClient = new TcpClient(ipAddress, sensorSCKPort);
                correct = true;
            } catch (Exception e) {
                correct = false;
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void a) {
            if (correct) {
                startTimer();
            }
        }
    }

    public class ImageStreamerTCP extends AsyncTask<Void, Void, Void> {

        public boolean correct;

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected Void doInBackground(Void... arg) {
            try {
                tcpImageStreamerClient = new TcpClient(ipAddress, imageStreameSCKPort);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void a) {
            startTimerImageStreamer();

        }
    }

}
