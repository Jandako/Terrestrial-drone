package com.example.pc_x.tankatron;


import android.util.Log;

public class RunnableTracking implements Runnable{
    public TcpClient tcp;
    public MainActivity.ImageStreamerTCP tcpImg;
    public boolean state;

    public RunnableTracking(TcpClient tcp, boolean state)
    {
        this.tcp=tcp;
        this.state=state;
    }
    @Override
    public void run() {

        MainActivity.trackingResponse="-1";
        int st=0;

        if(state)
        {
            st=1;
        }
        tcp.sendString("T#"+st+"#");
        String response = tcp.readString();
        MainActivity.trackingResponse=response;
        Log.d("Server response =>", response);
    }
}
